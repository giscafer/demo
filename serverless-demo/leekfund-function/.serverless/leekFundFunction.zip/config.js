module.exports = {
  reveiveEmail: 'giscafer@outlook.com', // 邮件通知对象，签到信息
  /* mail.js邮件发送者账号信息，此邮件发送到reveiveEmail */
  mail_opts: {
    host: 'smtp.qq.com',
    port: 465,
    secureConnection: true, // Fix Error: Greeting never received
    auth: {
      user: '2912285326@qq.com', // 邮箱账号 （改为你的，如果不是163，需要改host和post，不理解邮件协议请申请163邮箱测试）
      pass: 'laohoubin0716', // 密码（改为你的）
    },
  },
};
