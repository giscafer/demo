const App = require('./index');

App.main_handler();
