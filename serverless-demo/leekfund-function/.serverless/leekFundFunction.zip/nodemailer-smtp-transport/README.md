# nodemailer-smtp-transport

![Nodemailer](https://raw.githubusercontent.com/nodemailer/nodemailer/master/assets/nm_logo_200x136.png)

SMTP module with for Nodemailer.

See [Nodemailer homepage](https://nodemailer.com/smtp/) for documentation and terms of using SMTP.
